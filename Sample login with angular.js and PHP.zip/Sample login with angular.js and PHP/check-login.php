<?php 
if ( $_POST['username'] === 'TestPerson' && 
	$_POST['password'] === '1234' ) {
		echo 'correct';
} else {
		echo 'wrong'; 
}

?>


